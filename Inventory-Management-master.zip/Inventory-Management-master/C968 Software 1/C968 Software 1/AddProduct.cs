﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_1
{
    public partial class AddProduct : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        public Form4(IContainer components, Label label2, Label label1, Label label3, Label label4, Label label5, Label label6, Label label7, Button button1, TextBox textBox1, Button button2, Button button3, Button button4, Button button5, TextBox textBox2, TextBox textBox3, TextBox textBox4, TextBox textBox5, TextBox textBox6, TextBox textBox7, DataGridView partList, DataGridViewTextBoxColumn partID, DataGridViewTextBoxColumn partName, DataGridViewTextBoxColumn inventoryLevel, DataGridViewTextBoxColumn price, DataGridView dataGridView1, DataGridViewTextBoxColumn dataGridViewTextBoxColumn1, DataGridViewTextBoxColumn dataGridViewTextBoxColumn2, DataGridViewTextBoxColumn dataGridViewTextBoxColumn3, DataGridViewTextBoxColumn dataGridViewTextBoxColumn4)
        {
            this.components = components;
            this.label2 = label2;
            this.label1 = label1;
            this.label3 = label3;
            this.label4 = label4;
            this.label5 = label5;
            this.label6 = label6;
            this.label7 = label7;
            this.button1 = button1;
            this.textBox1 = textBox1;
            this.button2 = button2;
            this.button3 = button3;
            this.button4 = button4;
            this.button5 = button5;
            this.textBox2 = textBox2;
            this.textBox3 = textBox3;
            this.textBox4 = textBox4;
            this.textBox5 = textBox5;
            this.textBox6 = textBox6;
            this.textBox7 = textBox7;
            this.partList = partList;
            this.partID = partID;
            this.partName = partName;
            this.inventoryLevel = inventoryLevel;
            this.price = price;
            this.dataGridView1 = dataGridView1;
            this.dataGridViewTextBoxColumn1 = dataGridViewTextBoxColumn1;
            this.dataGridViewTextBoxColumn2 = dataGridViewTextBoxColumn2;
            this.dataGridViewTextBoxColumn3 = dataGridViewTextBoxColumn3;
            this.dataGridViewTextBoxColumn4 = dataGridViewTextBoxColumn4;
        }
    }
}
