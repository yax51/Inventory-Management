﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C968_Software_1
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddProduct addProduct = new AddProduct();
            addProduct.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            modProduct modProduct = new modProduct();
            modProduct.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addPart addPart = new addPart();
            addPart.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            modPart modPart = new modPart();
            modPart.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addPartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addPart addPart = new addPart();
            addPart.Show();
        }

        private void modifyPArtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modPart modPart = new modPart();
            modPart.Show();

        }

        private void addProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddProduct addProduct = new AddProduct();
            addProduct.Show();
        }

        private void modifyProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            modProduct modProduct = new modProduct();
            modProduct.Show();
        }
    }
}
