﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C968_Software_1
{
    public class Product
    {
        public int ProductID { get; set; }
        ArrayList associatedParts<Part>();

    }
    public void addAssociatedPart()
    {

    }
    public bool removeAssociatedPart()
    {

    }
    public int lookupAssociatedPart()
    {

    }   

    

}


