﻿namespace System.Collections
{
    public class ArrayList<T>
    {
    }
}