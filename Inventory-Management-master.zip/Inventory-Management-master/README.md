# Inventory-Management
An app to track and manage inventory (School project)
